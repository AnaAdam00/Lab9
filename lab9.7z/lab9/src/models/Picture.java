package models;

import models.Dimension;

public interface Picture {
    String url();

    Dimension dim();
}