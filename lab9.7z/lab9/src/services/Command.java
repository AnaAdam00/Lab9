package services;

public interface Command {
    void execute() throws Exception;
}