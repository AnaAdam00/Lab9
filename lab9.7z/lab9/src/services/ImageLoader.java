package services;

public interface ImageLoader {
    void load(String str);
}